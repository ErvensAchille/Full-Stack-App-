// config/database.js
module.exports = {

    'url' : 'mongodb+srv://snoopdogg:doggy@cluster0-xbglf.mongodb.net/test?retryWrites=true&w=majority', // looks like mongodb://<user>:<pass>@mongo.onmodulus.net:27017/Mikha4ot
    'dbName': 'demo'
};
